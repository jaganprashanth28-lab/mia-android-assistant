import 'dotenv/config';
import express from 'express';
import cors from 'cors';
const app = express();
app.use(cors());
app.use(express.json());
app.get('/health', (_req,res) => res.json({ok:true, service:'MIA token server'}));
app.post('/session', async (_req,res) => {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(503).json({error:'Server is missing OPENAI_API_KEY'});
  try {
    const r = await fetch('https://api.openai.com/v1/realtime/client_secrets', {
      method:'POST', headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},
      body: JSON.stringify({session:{type:'realtime',model:process.env.REALTIME_MODEL || 'gpt-realtime-2.1',instructions:'You are MIA, a helpful Tamil and English voice assistant. Speak naturally and politely. Ask before consequential actions.',audio:{output:{voice:'coral'}}}})
    });
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json({error:data.error?.message || 'Could not create Realtime client secret'});
    return res.json(data);
  } catch (e) { return res.status(500).json({error:'Token request failed'}); }
});
const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`MIA token server listening on ${port}`));
