import React from 'react';
import { View, Text, StyleSheet, Pressable, SafeAreaView } from 'react-native';
import { useState } from 'react';

export default function Home() {
  const [status, setStatus] = useState('Not connected');
  return <SafeAreaView style={s.safe}><View style={s.container}>
    <Text style={s.kicker}>PERSONAL AI ASSISTANT</Text>
    <Text style={s.title}>MIA</Text>
    <Text style={s.subtitle}>Tamil + English • Soft voice</Text>
    <View style={s.orb}><Text style={s.mic}>◉</Text></View>
    <Text style={s.status}>{status}</Text>
    <Pressable style={s.button} onPress={() => setStatus('Voice connection is the next milestone')}>
      <Text style={s.buttonText}>START VOICE (COMING NEXT)</Text>
    </Pressable>
    <Text style={s.note}>Milestone 1: app foundation only. Live microphone / Realtime audio is not connected yet.</Text>
  </View></SafeAreaView>;
}
const s = StyleSheet.create({safe:{flex:1,backgroundColor:'#07111f'},container:{flex:1,alignItems:'center',justifyContent:'center',padding:26},kicker:{color:'#78c9ff',letterSpacing:3,fontSize:11},title:{color:'white',fontSize:56,fontWeight:'800',letterSpacing:8,marginTop:10},subtitle:{color:'#a9bfd4',fontSize:15,marginTop:8},orb:{width:170,height:170,borderRadius:85,borderWidth:2,borderColor:'#39a9e8',backgroundColor:'#102b43',alignItems:'center',justifyContent:'center',marginTop:48,marginBottom:28},mic:{fontSize:54,color:'#8cdbff'},status:{color:'#d6e8f6',fontSize:16},button:{backgroundColor:'#1689c7',paddingVertical:16,paddingHorizontal:24,borderRadius:14,marginTop:28},buttonText:{color:'white',fontWeight:'700',letterSpacing:1},note:{color:'#8298aa',fontSize:12,textAlign:'center',marginTop:32,lineHeight:18}});
