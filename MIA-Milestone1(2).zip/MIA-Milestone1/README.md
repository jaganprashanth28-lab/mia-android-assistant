# MIA Android — Milestone 1 foundation

This is a starter scaffold, not a finished voice assistant or APK. It contains an Expo/React Native Android shell and a small server endpoint that requests a short-lived OpenAI Realtime client secret. The app UI deliberately labels voice as “coming next”; no microphone streaming, WebRTC transport, wake-word listener, Android accessibility service, alarms, or YouTube controls are implemented in this milestone.

## Phone-only workflow

1. Create a GitHub repository and upload this folder's contents.
2. Use a cloud development environment/build service from your Android browser (for example GitHub Codespaces or Expo EAS Build). Cloud build may require account setup and a paid quota; this repository does not create an APK by itself.
3. Install dependencies in the cloud terminal: `npm install`.
4. For Android cloud builds, configure Expo EAS and run `eas build --platform android --profile preview` after installing/configuring EAS CLI.
5. Deploy `server/` to a trusted HTTPS Node hosting service. Set `OPENAI_API_KEY` as a server-side secret. Never put the standard OpenAI API key in the mobile app or GitHub.
6. Set the app's backend URL in a future app configuration step before requesting sessions.

## Backend

`cd server && npm install && cp .env.example .env`, then add your API key to `.env` locally or as a hosting secret, and run `npm start`. `GET /health` checks service availability. `POST /session` creates a short-lived Realtime client secret using the server key.

## Next milestone

Implement the Android-compatible Realtime audio transport (WebRTC/native module), connect the app to `/session`, handle mic permission and audio lifecycle, then test Tamil/English speech. The browser-oriented Agents SDK snippet supplied by the project owner is not assumed to run unchanged inside React Native. Native Android action integrations will be developed separately with explicit permissions and user confirmation.

## Security

- Do not commit `.env` or API keys.
- Use HTTPS for the deployed token server.
- Short-lived client secrets belong only in memory and should not be logged.
- Review Android permissions and privacy before installing a build.
